class Profile{
  String email;
  String password;

  Profile({required this.email, required this.password});
}